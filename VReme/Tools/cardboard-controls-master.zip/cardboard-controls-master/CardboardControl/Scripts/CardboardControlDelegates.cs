﻿using UnityEngine;
using System.Collections;

namespace CardboardControlDelegates {
  public delegate void CardboardControlDelegate(object sender);
}
