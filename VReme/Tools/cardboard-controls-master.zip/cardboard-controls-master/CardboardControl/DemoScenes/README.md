ControlsDemo documents the Cardboard Controls+ API extensively through thorough documentation.

MovingDemo shows you how to take that API and create an explorable first-person world with it.
